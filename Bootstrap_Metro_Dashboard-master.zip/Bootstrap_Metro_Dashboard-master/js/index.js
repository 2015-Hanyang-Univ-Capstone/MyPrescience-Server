$( document ).ready(function() {
	
    console.log( "Index Page ready!" );
    
    GomlogDB('getMySQLUsage', makeMySQLUsage);
    
});