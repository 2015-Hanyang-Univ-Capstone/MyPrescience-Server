<?php 
	class Dao
	{
	     
	    function getConnection(){
// 	        $connectionString =mysql_connect("192.168.0.99:8889", "root", "myp1234");
	    	$connectionString =mysql_connect("localhost:8889", "root", "root");
	        mysql_select_db("exercise_myp", $connectionString);
	         
	        mysql_query("set session character_set_connection=utf8;");
	        mysql_query("set session character_set_results=utf8;");
	        mysql_query("set session character_set_client=utf8;");
	        
	        return $connectionString;  
	    }
	     
	    public function getResultSet($connection, $query){
	        $result = mysql_query($query);
	        mysql_close($connection);
	         
	        return $result;
	    }
	     
	    public function selectAll( $resultSet  ){
	        $resultArray = array();
	        while( $rs = mysql_fetch_array( $resultSet ) ){
	        	
	        	
	            $arrayMiddle = array(
	            		 "ip"=>$rs['ip'],
	            		 "date"=>$rs['date'],
	            		 "time"=>$rs['time'],
	            		 "title"=>$rs['title'],
	            		 "artist"=>$rs['artist'],
	            		 "album"=>$rs['album'],
	            		 "duration"=>$rs['duration'],
	            		 "size"=>$rs['size'],
	            		 "utc"=>$rs['utc'],
	            		 "version"=>$rs['version']
	               );
	             
	            array_push($resultArray, $arrayMiddle);
	        }
	        return $resultArray;
	    }
	    
	    public function selectUserTop10( $resultSet  ){
	    	$resultArray = array();
	    	while( $rs = mysql_fetch_array( $resultSet ) ){
	    
	    
	    		$arrayMiddle = array(
	    				"title"=>$rs['title'],
	    				"artist"=>$rs['artist'],
	    				"album"=>$rs['album'],
	    				"play_count"=>$rs['play_count'],
	    		);
	    
	    		array_push($resultArray, $arrayMiddle);
	    	}
	    	return $resultArray;
	    }
	    
	    public function selectTitle( $resultSet  ){
	    	$resultArray = array();
	    	while( $rs = mysql_fetch_array( $resultSet ) ){
	    	  
	    	  
	    		$arrayMiddle = array(
	    				"title"=>$rs['title']
	    		);
	    	  
	    		array_push($resultArray, $arrayMiddle);
	    	}
	    	return $resultArray;
	    }
	    
	    public function getMySQLUsage( $resultSet  ){
	    	$resultArray = array();
	    	while( $rs = mysql_fetch_array( $resultSet ) ){
	    
	    
	    		$arrayMiddle = array(
	    				"MAXSize"=>$rs['MAXSize']
	    		);
	    
	    		array_push($resultArray, $arrayMiddle);
	    	}
	    	return $resultArray;
	    }
	    
	    public function Response( $resultSet  ){
	    
	    	$resultArray = array();
	    	if($resultSet) {
	    		$arrayMiddle = array(
	    				"result"=>true
	    		);
	    	} else {
	    		$arrayMiddle = array(
	    				"result"=>false
	    		);
	    	}
	    
	    	array_push($resultArray, $arrayMiddle);
	    	return $resultArray;
	    }
	         
	}

?>